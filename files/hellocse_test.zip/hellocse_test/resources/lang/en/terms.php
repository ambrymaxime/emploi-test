<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Terms Pages Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'publicPage' => [
        'title' => 'Terms',
        'term1' => 'This site may use cookies to better your experience.',
        'term2' => 'Public profile data on this site such as username, first name, user bio, twitter username, and github username may be visible to other users.',
        'term3' => 'This save protects user data and does make it public or sell it.',
        'term4' => '',
        'term5' => '',
        'term6' => '',
        'term7' => '',
        'term8' => '',
    ],
];
