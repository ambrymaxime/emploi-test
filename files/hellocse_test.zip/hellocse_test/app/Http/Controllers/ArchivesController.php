<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class ArchivesController extends Controller
{
    /**
     *  Get all archives
     *  
     *  @return Kans modifié
     */
    public function getAllArchives()
    {
        $kans = "ZZZZZZZZZZZZZZZZZZZZZ";
        return $kans;
    }
}
